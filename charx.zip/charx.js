﻿function CharxFlashHtml(id,w,h,swf,key )
{
    var swfNode = "";
    if (!swf)
        swf = 'charx.swf';
    if (!key)
        key = '3aa66b63663f83cbc379259a3791bdc65ff34c54';
     var flashvars='id='+ id 
             + '&key=' + key ;
     
    if (navigator.plugins && navigator.mimeTypes && navigator.mimeTypes.length) { 
		// netscape plugin architecture			
		swfNode = '<embed type="application/x-shockwave-flash" src="'+ swf +'" width="'+ w +'" height="'+ h +'"  ';
		swfNode += ' id="'+ id +'" name="'+ id +'" ';
         swfNode += 'wmode="transparent" '; 
		swfNode += ' flashvars="' + flashvars + '" ';
		swfNode += '/>';
	} else { // PC IE			
		swfNode = '<object id="'+ id +'" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="'+ w +'" height="'+ h +'">';
		swfNode += '<param name="wmode" value="transparent" />';
		swfNode += '<param name="movie" value="'+ swf +'" />';
		swfNode += '<param name="flashvars" value="' + flashvars + '" />';
		swfNode += "</object>";
	}
    return swfNode;
}
function CharxCreate(panelId, id, w, h, swf, key)
{
	var panel=document.getElementById(panelId);
	if (!panel)
	    return;
	var swfNode = CharxFlashHtml(id, w, h, swf, key);
    panel.innerHTML=swfNode;
}
function CharxSetData(id,xml)
{
    var chartObj=document.getElementById(id);
	if (!chartObj)
	    return;
   var intr= window.setInterval(function()
   {
        if (chartObj.SetXmlString)
        {
            window.clearInterval(intr);
            try
            {
                chartObj.SetXmlString(xml);
            } catch (e)
            {
            throw (e + '\n' + id);
            }
        }
    },100);
}